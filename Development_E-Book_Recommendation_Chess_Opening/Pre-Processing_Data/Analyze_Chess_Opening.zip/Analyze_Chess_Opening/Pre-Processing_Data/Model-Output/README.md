#  Accuracy Winrate Model Output

## Description

In this project, we perform data analysis using a Accurary Winrate model. The output of this model illustrates how Accurary are made based on the attributes present in the preprocessed dataset.
# White 
| Opening Move | Total Games  | Win Rate    |
|--------------|--------------|-------------|
| b3           | 64           | 0.562500    |
| c4           | 397          | 0.500000    |
| e4           | 655          | 0.520611    |

# Black
| Opening Move | Total Games | Win Rate  |
|--------------|-------------|-----------|
| Nf           | 254         | 0.423228  |
| b3           | 76          | 0.480263  |
| c4           | 96          | 0.572917  |
| d4           | 728         | 0.466346  |
| e4           | 1142        | 0.449212  |
| g3           | 30          | 0.600000  |

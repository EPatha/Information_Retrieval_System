# Pre-Processing Dataset
Processing the Raw Dataset

The initial dataset contains 5 variables:

    White
    Black
    Date
    Results
    Moves

For analysis, only 2 variables will be extracted:

    Results
    Moves
Black and white are not used because they were splitted when PGN went to Excel
